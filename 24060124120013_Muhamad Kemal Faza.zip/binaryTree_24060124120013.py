def Akar(PN):
    return PN[1]
